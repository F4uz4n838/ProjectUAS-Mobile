package com.example.moodify

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
