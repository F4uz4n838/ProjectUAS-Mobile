import 'package:flutter/material.dart';
import 'api_service.dart';

class ArticlePage extends StatefulWidget {
  const ArticlePage({super.key});

  @override
  State<ArticlePage> createState() => _ArticlePageState();
}

class _ArticlePageState extends State<ArticlePage> {
  late Future<List> articles;

  @override
  void initState() {
    super.initState();
    refreshData();
  }

  void refreshData() {
    setState(() {
      articles = ApiService.getArticles();
    });
  }

  void showAddDialog() {
    final titleController = TextEditingController();
    final contentController = TextEditingController();
    final imageController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Tambah Artikel"),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: titleController,
                decoration: const InputDecoration(labelText: "Judul"),
              ),
              TextField(
                controller: contentController,
                decoration: const InputDecoration(labelText: "Isi"),
                maxLines: 3,
              ),
              TextField(
                controller: imageController,
                decoration: const InputDecoration(labelText: "URL Gambar"),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            child: const Text("Batal"),
            onPressed: () => Navigator.pop(context),
          ),
          ElevatedButton(
            child: const Text("Simpan"),
            onPressed: () async {
              bool success = await ApiService.addArticle(
                titleController.text,
                contentController.text,
                imageController.text,
              );

              if (!mounted) return;

              Navigator.pop(context);

              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    success ? "Artikel ditambahkan" : "Gagal menambah artikel",
                  ),
                ),
              );

              if (success) refreshData();
            },
          ),
        ],
      ),
    );
  }

  void deleteArticle(String id) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Hapus Artikel"),
        content: const Text("Yakin ingin menghapus artikel ini?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Batal"),
          ),
          ElevatedButton(
            onPressed: () async {
              bool success = await ApiService.deleteArticle(id);

              if (!mounted) return;

              Navigator.pop(context);

              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    success ? "Artikel dihapus" : "Gagal menghapus artikel",
                  ),
                ),
              );

              if (success) refreshData();
            },
            child: const Text("Hapus"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: showAddDialog,
        child: const Icon(Icons.add),
      ),
      body: FutureBuilder<List>(
        future: articles,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final data = snapshot.data!;

          if (data.isEmpty) {
            return const Center(child: Text("Belum ada artikel"));
          }

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: data.length,
            itemBuilder: (context, i) {
              return Card(
                elevation: 3,
                margin: const EdgeInsets.only(bottom: 12),
                child: ListTile(
                  leading: Image.network(
                    data[i]['image'],
                    width: 50,
                    fit: BoxFit.cover,
                  ),
                  title: Text(data[i]['title']),
                  subtitle: Text(
                    data[i]['content'],
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () => deleteArticle(data[i]['id']),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
