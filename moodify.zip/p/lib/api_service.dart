import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static String baseUrl = "https://tifaw.my.id/mobile_alif/moodify_apialif";

  // ===================== LOGIN =====================
  static Future<bool> login(String username, String password) async {
    try {
      var response = await http.post(
        Uri.parse("$baseUrl/login.php"),
        body: {
          'username': username.trim(),
          'password': password.trim(),
        },
      );

      if (response.statusCode == 200) {
        var data = json.decode(response.body);
        return data['status'] == 'success';
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // ===================== REGISTER =====================
  static Future<bool> register(String username, String password) async {
    try {
      var response = await http.post(
        Uri.parse("$baseUrl/register.php"),
        body: {
          'username': username.trim(),
          'password': password.trim(),
        },
      );

      if (response.statusCode == 200) {
        var data = json.decode(response.body);
        return data['status'] == 'success';
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // ===================== GET ARTICLES =====================
  static Future<List> getArticles() async {
    try {
      var response = await http.get(
        Uri.parse("$baseUrl/get_articles.php"),
      );

      if (response.statusCode == 200) {
        var jsonData = json.decode(response.body);

        // API langsung array
        if (jsonData is List) {
          return jsonData;
        }

        // API pakai {status, data}
        if (jsonData is Map && jsonData['data'] != null) {
          return jsonData['data'];
        }
      }

      return [];
    } catch (e) {
      return [];
    }
  }

  // ===================== ADD ARTICLE =====================
  static Future<bool> addArticle(
      String title,
      String content,
      String image,
      ) async {
    try {
      var response = await http.post(
        Uri.parse("$baseUrl/add_article.php"),
        body: {
          'title': title,
          'content': content,
          'image': image,
        },
      );

      if (response.statusCode == 200) {
        var data = json.decode(response.body);
        return data['status'] == 'success';
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // ===================== DELETE ARTICLE =====================
  static Future<bool> deleteArticle(String id) async {
    try {
      var response = await http.post(
        Uri.parse("$baseUrl/delete_article.php"),
        body: {
          'id': id,
        },
      );

      if (response.statusCode == 200) {
        var data = json.decode(response.body);
        return data['status'] == 'success';
      }
      return false;
    } catch (e) {
      return false;
    }
  }
}
