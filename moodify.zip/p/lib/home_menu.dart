import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeMenu extends StatefulWidget {
  const HomeMenu({super.key});

  @override
  State<HomeMenu> createState() => _HomeMenuState();
}

class _HomeMenuState extends State<HomeMenu> {
  String mood = "Netral 😐";
  String username = "User";

  final List<Map<String, dynamic>> moods = [
    {
      "label": "Bahagia 😊",
      "icon": Icons.sentiment_very_satisfied,
      "color": Colors.yellow,
    },
    {
      "label": "Tenang 😌",
      "icon": Icons.self_improvement,
      "color": Colors.green,
    },
    {
      "label": "Semangat 💪",
      "icon": Icons.flash_on,
      "color": Colors.orange,
    },
    {
      "label": "Sedih 😢",
      "icon": Icons.sentiment_dissatisfied,
      "color": Colors.blue,
    },
    {
      "label": "Capek 😴",
      "icon": Icons.bedtime,
      "color": Colors.purple,
    },
    {
      "label": "Kesal 😡",
      "icon": Icons.sentiment_very_dissatisfied,
      "color": Colors.red,
    },
  ];

  @override
  void initState() {
    super.initState();
    loadUserData();
  }

  // ambil username & mood dari SharedPreferences
  void loadUserData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      username = prefs.getString('username') ?? 'User';
      mood = prefs.getString('mood') ?? "Netral 😐";
    });
  }

  void saveMood(String value) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('mood', value);

    setState(() {
      mood = value;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Mood disimpan: $value"),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          const SizedBox(height: 30),

          // ===== HALO USER =====
          Text(
            "Halo, $username 👋",
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 8),

          const Text(
            "Bagaimana perasaanmu hari ini?",
            style: TextStyle(
              fontSize: 18,
              color: Colors.grey,
            ),
            textAlign: TextAlign.center,
          ),

          const SizedBox(height: 10),

          Text(
            mood,
            style: const TextStyle(
              fontSize: 18,
              color: Colors.blueGrey,
            ),
          ),

          const SizedBox(height: 30),

          Card(
            elevation: 6,
            margin: const EdgeInsets.symmetric(horizontal: 20),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: moods.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 1.2,
                ),
                itemBuilder: (context, index) {
                  final item = moods[index];
                  return InkWell(
                    onTap: () => saveMood(item["label"]),
                    borderRadius: BorderRadius.circular(16),
                    child: Container(
                      decoration: BoxDecoration(
                        color: item["color"].withOpacity(0.15),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            item["icon"],
                            size: 40,
                            color: item["color"],
                          ),
                          const SizedBox(height: 10),
                          Text(
                            item["label"],
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

          const SizedBox(height: 30),
        ],
      ),
    );
  }
}
