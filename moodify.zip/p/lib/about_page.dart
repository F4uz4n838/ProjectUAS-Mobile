import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, // ⬅ rata kiri
          children: [
            const SizedBox(height: 20),

            /// ICON & TITLE (tetap tengah)
            Center(
              child: Column(
                children: const [
                  Icon(Icons.favorite, size: 90, color: Colors.red),
                  SizedBox(height: 16),
                  Text(
                    "Moodify",
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    "Your Daily Mood Companion",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),

            /// DESKRIPSI
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  "Moodify adalah aplikasi mobile yang dirancang untuk membantu "
                      "pengguna mengenali dan mengelola suasana hati mereka. "
                      "Aplikasi ini menyediakan fitur pemilihan mood harian, "
                      "artikel inspiratif, serta pesan motivasi yang dapat "
                      "membantu meningkatkan semangat dan kesehatan mental.",
                  textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 16),
                ),
              ),
            ),

            const SizedBox(height: 30),

            /// JUDUL FITUR
            const Text(
              "Fitur Utama",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 16),

            /// LIST FITUR (RATA KIRI)
            _featureItem(Icons.mood, "Pemilihan mood harian kamu"),
            _featureItem(Icons.article, "Artikel motivasi"),
            _featureItem(Icons.message, "Pesan penyemangat"),
            _featureItem(Icons.lock, "Login & penyimpanan lokal"),
            _featureItem(Icons.phone_android, "Antarmuka sederhana & nyaman"),

            const SizedBox(height: 30),

            /// FOOTER
            const Center(
              child: Text(
                "Dibuat untuk memenuhi tugas Ujian Akhir Semester (UAS)",
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }

  static Widget _featureItem(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: Colors.blue),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }
}
