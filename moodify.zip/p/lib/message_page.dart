import 'package:flutter/material.dart';

class MessagePage extends StatelessWidget {
  const MessagePage({super.key});

  final List<String> messages = const [
    "Ingat, kamu tidak sendirian 🌈",
    "Hari ini berat, tapi kamu lebih kuat 💪",
    "Semua akan membaik, pelan-pelan ya 🌱",
    "Istirahat sejenak juga bagian dari berjuang 😌",
    "Kamu sudah melakukan yang terbaik 💙",
    "Tidak apa-apa merasa lelah, yang penting jangan menyerah 🌤️",
    "Setiap langkah kecil tetap berarti 🚶‍♂️",
    "Hari buruk tidak menentukan masa depanmu 🌙",
    "Tarik napas, hembuskan, kamu aman di sini 🫶",
    "Kamu berharga, apa pun kondisimu hari ini ✨",
    "Tidak apa-apa meminta bantuan 🤝",
    "Besok adalah kesempatan baru 🌅",
    "Percaya pada proses, kamu sedang bertumbuh 🌿",
    "Kamu pantas mendapatkan kebahagiaan 😊",
    "Pelan-pelan saja, tidak perlu terburu-buru ⏳",
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: messages.length,
      itemBuilder: (context, index) {
        return Card(
          elevation: 4,
          margin: const EdgeInsets.only(bottom: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Text(
              messages[index],
              style: const TextStyle(fontSize: 18),
              textAlign: TextAlign.center,
            ),
          ),
        );
      },
    );
  }
}
